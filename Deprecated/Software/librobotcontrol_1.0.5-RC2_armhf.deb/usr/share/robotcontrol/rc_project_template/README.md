This is meant to be a starting point for your own project.

For full instructions on how to use this template, see:

<http://strawsondesign.com/docs/librobotcontrol/docs/html/project_template.html>
