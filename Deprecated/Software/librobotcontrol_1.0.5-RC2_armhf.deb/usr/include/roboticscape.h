/**
 * <roboticscape.h>
 *
 * deprecated header, use <robotcontrol.h> instead. This exists only for backwards compatability.
 *
 * @addtogroup Robotics_Cape
 * @ingroup Deprecated
 * @{
 */

#include <robotcontrol.h>


///@} end group Robotics_Cape





