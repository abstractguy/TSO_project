/**
 * @file common.h
 */

#define CALIBRATION_DIR		"/var/lib/robotcontrol/"