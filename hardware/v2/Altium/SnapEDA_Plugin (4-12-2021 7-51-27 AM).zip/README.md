# snapeda-altium-plugin
SnapEDA Plugin for Altium
